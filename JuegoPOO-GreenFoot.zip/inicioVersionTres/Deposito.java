import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Deposito here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Deposito extends Construcciones
{
    private int recursoProto;
    private int recursoTerran;
    
    /**
     * Act - do whatever the Deposito wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        guardadoProto();
        guardadoTerran();
    }   

    public Deposito(){
        recursoProto = 0;
        recursoTerran = 0;
    }

    // mejorarara    
    ///   
    ////
    public void guardadoProto(){
        Actor a = this.getOneIntersectingObject(ConstructorProto.class);       
        if (a != null){
            setRecursoProto(30);
        }
    }

    public void guardadoTerran(){
        Actor a = this.getOneIntersectingObject(ConstructorTerran.class);
        if(a != null){
            setRecursoTerran(30);
        }
    }

    public int getRecursoProto(){
        return recursoProto;
    }

    public void setRecursoProto( int recursoProto ){
        this.recursoProto +=  recursoProto;
    }

   
    public int getRecursoTerran(){
        return recursoTerran;
    }

    public void setRecursoTerran( int recursoTerran ){
        this.recursoTerran +=  recursoTerran;
    }

    
}
