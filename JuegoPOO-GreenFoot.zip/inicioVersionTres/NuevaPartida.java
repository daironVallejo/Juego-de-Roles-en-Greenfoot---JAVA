import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class NuevaPartida here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NuevaPartida extends World
{
       

    /**
     * Constructor for objects of class NuevaPartida.
     * 
     */
    public NuevaPartida()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 600, 1);  
         NuevaPardida s1 = new NuevaPardida();
          addObject(s1,600,250);
          Salir1 s11 = new Salir1();
          addObject(s11,600,450);
          Creditos c1 = new Creditos();
          addObject(c1,600,350);

          
    }
}
