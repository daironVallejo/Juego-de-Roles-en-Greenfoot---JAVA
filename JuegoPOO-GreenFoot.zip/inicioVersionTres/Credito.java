import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Credito here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Credito extends World
{

    /**
     * Constructor for objects of class Credito.
     * 
     */
    public Credito()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 600, 1); 

        Letrero l1 = new Letrero("CREADORES:");
        addObject(l1, 200,200);
        Letrero l2 = new Letrero( "DAIRON  VALLEJO ");
        addObject(l2, 200,300);
        Letrero l3 = new Letrero( "ERIKA LACHE");
        addObject(l3, 200,380);
        Letrero l4 = new Letrero( "JORGE SAUL");
        addObject(l4, 200,460);
        Salir s1 = new Salir();
        addObject(s1, 200, 550);
    }
}
